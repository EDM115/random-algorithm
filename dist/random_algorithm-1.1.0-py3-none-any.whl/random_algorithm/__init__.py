from .random_algorithm import (
    ascii_reduce,
    gen_random,
    get_time_seed,
    reduce_to_single_digit,
)
