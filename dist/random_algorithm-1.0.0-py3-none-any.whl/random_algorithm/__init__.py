from .random_algorithm import ascii_reduce, gen_random
